document.addEventListener('DOMContentLoaded', function() {   
    updateCartDisplay(); // Используем функцию для инициализации корзины 
});   
 
function removeItem(index) {   
    let cart = JSON.parse(localStorage.getItem('cart')) || []; // Исправлено здесь 
    cart.splice(index, 1);  
    localStorage.setItem('cart', JSON.stringify(cart));  
    updateCartDisplay(); // Обновляем отображение корзины  
}  
  
function updateCartDisplay() {  
    const cartItems = document.getElementById('cartItems');  
    cartItems.innerHTML = ''; // Очищаем текущее содержимое  
    let cart = JSON.parse(localStorage.getItem('cart')) || [];  
    let total = 0;  
  
    cart.forEach((item, index) => {  
        const productDiv = document.createElement('div');  
        productDiv.className = 'product';  
        productDiv.innerHTML = `  
            <img src="${item.image}" alt="${item.name}" class="cart-image">  
            <h2>${item.name}</h2>  
            <p class="price">${item.price} тг</p>  
            <button class="remove-item-button" onclick="removeItem(${index})">Удалить</button>  
        `;  
        cartItems.appendChild(productDiv);  
        total += item.price;  
    });  
  
    document.getElementById('totalPrice').textContent = total + ' тенге';  
}