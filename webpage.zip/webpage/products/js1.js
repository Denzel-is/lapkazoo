
function addToCart(price, name, image) {   
     let cart = JSON.parse(localStorage.getItem('cart')) || [];
    cart.push({ name, price, image });  
      localStorage.setItem('cart', JSON.stringify(cart));
}




    function redirectTo(url) {
        window.location.href = url;
    }
    


document.getElementById('searchInput').addEventListener('input', function(e) {
    var searchTerm = e.target.value.toLowerCase();
    var products = document.querySelectorAll('.product');

    products.forEach(function(product) {
        var productName = product.querySelector('h2').textContent.toLowerCase();
        if (productName.includes(searchTerm)) {
            product.style.display = 'block';
        } else {
            product.style.display = 'none';
        }
    });
});





