
        function scrollToTop() {
            window.scrollTo({
                top: 0,
                behavior: "smooth"
            });
        }

        function scrollToProducts() {
            const productsSection = document.querySelector(".products");
            productsSection.scrollIntoView({
                behavior: "smooth"
            });
        }

        function scrollToContacts() {
            const footer = document.querySelector("footer");
            footer.scrollIntoView({
                behavior: "smooth"
            });
        }
 