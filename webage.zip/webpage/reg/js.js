function togglePasswordVisibility(inputId) {
    const input = document.getElementById(inputId);
    const toggle = document.getElementById(`${inputId}-toggle`);

    if (input.type === "password") {
        input.type = "text";
        toggle.innerHTML = "&#128064;"; // Показать символы
    } else {
        input.type = "password";
        toggle.innerHTML = "&#128065;"; // Скрыть символы
    }
}

document.getElementById("registration-form").addEventListener("submit", function (e) {
    const password = document.getElementById("password").value;
    const confirmPassword = document.getElementById("confirm-password").value;
    const passwordMismatchError = document.getElementById("password-mismatch-error");

    if (password !== confirmPassword) {
        passwordMismatchError.style.display = "block"; // Показать сообщение об ошибке
        e.preventDefault(); // Отменить отправку формы
    }
});
