from flask import Flask, render_template, request,session,redirect
import psycopg2
import os


def connectionbd():
    connection = psycopg2.connect(user="postgres",
                                  password="123",
                                  host="78.141.227.124",
                                  port="5432",
                                  database="lapka")
    return connection

app = Flask(__name__)
app.secret_key = 'CYuyvwegn5619846467oipjguh6568461254rgiubwigb'


@app.route('/')
def mainp():
    connection = connectionbd()
    cursor = connection.cursor()
    cursor.execute('SELECT name, map, links FROM categories')
    data = cursor.fetchall()
    cursor.close()
    connection.close()
    return render_template('html.html', postgres_data=data)

def fetch_products(category_id, query=None):
    connection = connectionbd()
    cursor = connection.cursor()
    if query:
        sql_query = "SELECT product_id, name, description, price, stock_quantity, map_p FROM products WHERE product_id IN (SELECT product_id FROM product_categories WHERE category_id = %s) AND name ILIKE %s"
        cursor.execute(sql_query, (category_id, '%' + query + '%'))
    else:
        sql_query = "SELECT product_id, name, description, price, stock_quantity, map_p FROM products WHERE product_id IN (SELECT product_id FROM product_categories WHERE category_id = %s)"
        cursor.execute(sql_query, (category_id,))
    data = cursor.fetchall()
    cursor.close()
    connection.close()
    return data

def fetch_product_details(product_id):
    connection = connectionbd()
    cursor = connection.cursor()
    cursor.execute("SELECT product_id, name, description, price, stock_quantity, map_p FROM products WHERE product_id = %s", (product_id,))
    product = cursor.fetchone()
    cursor.close()
    connection.close()
    if product:
        # Изменение пути к изображению
        product = list(product)
        product[5] = product[5].replace('./static/', '/static/')
    return product




@app.route('/cats')
def cats():
    query = request.args.get('query')
    data = fetch_products(2, query)
    return render_template('catc.html', postgres_data=data)

@app.route('/dogs')
def dogs():
    query = request.args.get('query')
    data = fetch_products(1, query)
    return render_template('catd.html', postgres_data=data)

@app.route('/rodents')
def rodents():
    query = request.args.get('query')
    data = fetch_products(3, query)
    return render_template('catr.html', postgres_data=data)

@app.route('/birds')
def birds():
    query = request.args.get('query')
    data = fetch_products(4, query)
    return render_template('catb.html', postgres_data=data)

@app.route('/product/<int:product_id>')
def product_details(product_id):
    product = fetch_product_details(product_id)
    if product:
        return render_template('prods.html',
                               product_id=product[0],
                               product_name=product[1],
                               product_description=product[2],
                               product_price=product[3],
                               product_stock=product[4],
                               product_image_url=product[5])
    else:
        return "Продукт не найден", 404

def category_route(category_id):
    query = request.args.get('query')
    data = fetch_products(category_id, query)
    return render_template(f'cat{category_id}.html', postgres_data=data)

# Маршрут для корзины

@app.route('/cart', methods=['GET', 'POST'])
def remove_from_cart_db(product_id):
    connection = connectionbd()
    cursor = connection.cursor()
    # Удаление товара из корзины по product_id
    cursor.execute("DELETE FROM cart WHERE product_id = %s", (product_id,))
    connection.commit()
    cursor.close()
    connection.close()

def cart():
    if 'cart' not in session:
        session['cart'] = []

    if request.method == 'POST':
        product_id = request.form.get('product_id')
        if product_id:
            product_id = int(product_id)  # Преобразуйте product_id в число

        action = request.form.get('action')

        if action == 'add':
            if product_id not in session['cart']:
                session['cart'].append(product_id)
        elif action == 'remove':
            if product_id in session['cart']:
                # Удаляем товар из корзины в базе данных
                remove_from_cart_db(product_id)
                # Удаляем товар из сессионной корзины
                session['cart'].remove(product_id)

        session.modified = True

    # Здесь код для получения данных корзины из БД и отображения на странице
    cart_data = get_cart_data_from_db(session['cart'])
    total = sum(item['price'] for item in cart_data)

    return render_template('cart.html', cart_data=cart_data, total=total)


def get_cart_data_from_db(cart_items):
    connection = connectionbd()
    cursor = connection.cursor()
    cart_data = []
    for product_id in cart_items:
        cursor.execute("SELECT name, price, map_p FROM products WHERE product_id = %s", (product_id,))
        product_data = cursor.fetchone()
        if product_data:
            cart_data.append({
                'product_id': product_id,
                'name': product_data[0],
                'price': product_data[1],
                'image_url': product_data[2].replace('./static/', '/static/')
            })
    cursor.close()
    connection.close()
    return cart_data





@app.route('/add_to_cart', methods=['POST'])

def add_to_cart():
    def add_to_cart_db(product_id):
         connection = connectionbd()
         cursor = connection.cursor()
         try:
        # Здесь предполагается, что у вас есть поле cart_id для идентификации пользователя или сессии.
        # Если такого поля нет, вам нужно будет его добавить в вашу схему базы данных.
             cart_id = 1  # Пример, замените на актуальный идентификатор корзины пользователя

        # Добавление товара в таблицу cart
             cursor.execute("INSERT INTO cart (cart_id, product_id) VALUES (%s, %s)", (cart_id, product_id))
             connection.commit()
         except Exception as e:
           print(f"Ошибка при добавлении товара в корзину: {e}")
         finally:
             cursor.close()
             connection.close()

    product_id = request.form.get('product_id')
    if product_id:
        product_id = int(product_id)

    if 'cart' not in session:
        session['cart'] = []

    if product_id and product_id not in session['cart']:
        session['cart'].append(product_id)
        # Добавляем товар в корзину в БД
        add_to_cart_db(product_id)

    session.modified = True
    return redirect(request.referrer or '/')

if __name__ == '__main__':
    app.run(debug=True, port=8000)


